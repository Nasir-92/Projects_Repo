package com.pmdm.ecobite.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavOptionsBuilder
import androidx.navigation.PopUpToBuilder
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.rememberNavController
import com.pmdm.ecobite.ui.features.Receta.RecetaViewModel
import com.pmdm.ecobite.ui.features.Restaurante.RestauranteViewModel
import com.pmdm.ecobite.ui.features.inicio.InicioViewModel
import com.pmdm.ecobite.ui.features.login.LoginViewModel

@Composable
fun EcoBiteNavHost(
    vmLogin: LoginViewModel,
    vmInicio: InicioViewModel,
    vmRestaurante: RestauranteViewModel,
    vmReceta: RecetaViewModel
) {

    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = LoginRoute
    ) {

        loginDestination(
            vm = vmLogin,
            onLoginSuccess = {

                navController.navigate(InicioRoute) {
                    popUpTo(LoginRoute) { inclusive = true }
                }

            }
        )

        inicioDestination(
            vm = vmInicio,
            onNavigateRestaurante = { id ->
                navController.navigate(RestauranteRoute(id))
            },
            onNavigateReceta = {
                navController.navigate(RecetaRoute(it))
            }
        )

        restauranteDestination(
            vm = vmRestaurante,
            onNavigateReceta = { id ->
                navController.navigate(RecetaRoute(id))
            },
            onBack = {
                navController.popBackStack()
            }
        )

        recetaDestination(
            vm = vmReceta,
            onNavigateRestaurante = { id ->
                navController.navigate(RestauranteRoute(id))
            },
            onBack = {
                navController.popBackStack()
            }
        )

    }
}