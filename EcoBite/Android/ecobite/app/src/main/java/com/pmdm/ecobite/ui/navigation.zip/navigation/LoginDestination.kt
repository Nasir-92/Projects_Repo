package com.pmdm.ecobite.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.ecobite.ui.features.login.LoginEvent
import com.pmdm.ecobite.ui.features.login.LoginScreen
import com.pmdm.ecobite.ui.features.login.LoginViewModel

fun NavGraphBuilder.loginDestination(
    vm: LoginViewModel,
    onLoginSuccess: () -> Unit
) {

    composable<LoginRoute> {

        LoginScreen(
            loginUiState = vm.uiState.value,
            onLoginEvent = { event ->

                vm.onEvent(event)

                if (event is com.pmdm.ecobite.ui.features.login.LoginEvent.OnLoginClick) {

                    // si login correcto navega
                    if (vm.uiState.value.errorMessage == null) {
                        onLoginSuccess()
                    }

                }
            }
        )
    }
}